//
//  onBoarding.swift
//  NanoChallenge2
//
//  Created by Haya Fahad Alsabr on 12/06/1445 AH.
//



import SwiftUI

struct ContentView: View {
   @AppStorage("_showOnboarding") var showOnboarding : Bool=true
    var body: some View {
        NavigationView{
            VStack{
                Text("main").padding()
            }
            .navigationTitle("HOME ")
        }
    .fullScreenCover(isPresented: $showOnboarding, content:{
        Onboarding_View(showOnboarding:$showOnboarding)
        })
    }
}
 //onboarding
struct Onboarding_View:View {
   @Binding var showOnboarding : Bool
   var body: some View {
       TabView{
           PageView(title: "Welcome to InspiroBoard",
                    Subtitle: "Your Creative Playground! \n Learn the art of mood boards with our app." ,
                    
                    image: "inspiro" , DismissBoutton:false , DismissBoutton2:true , showOnboarding:$showOnboarding)
           
           
           PageView(title: "Customize with a Click!",
                    Subtitle: "Add images, click, and see your vision come to life! \n Curious? Tap info for a quick guide and Let creativity flow! " ,
                    image: "texture" , DismissBoutton:false , DismissBoutton2:true , showOnboarding:$showOnboarding)
           
           PageView(title: "Export Your Masterpieces! ",
                    Subtitle: "With a one click, save your creation into a timeless image!" ,
                    
                    image: "save" , DismissBoutton:true , DismissBoutton2:true,  showOnboarding:$showOnboarding )
         
       }.ignoresSafeArea()
       .tabViewStyle(PageTabViewStyle())
       
   }
}
struct PageView: View {
   let title : String
   let Subtitle : String
   let image : String
   let DismissBoutton : Bool
   let DismissBoutton2 : Bool
   @Binding var showOnboarding : Bool

   var body: some View {
       ZStack{
           Color(.bg)
               .ignoresSafeArea()
           VStack{
               
               
               
               
               
               HStack{
                   
                   Spacer()
                   
                   
                   
                   if DismissBoutton2{
                       Button(action: {
                          showOnboarding.toggle()
                       }, label:{
                           
                           
                           Text("Skip")
                               .accessibilityLabel("skip")
                           
                               .foregroundColor(ColorPalette.buttonColor)
                           
                      
                               .padding(.top, 70)
                               .padding()
                               .padding(.trailing,20)
                             
                           
                           
                           
                           
                       })
                       
                   }
                   
                   
               }
               Spacer()
               
               VStack{
                   
                   
                   Image(image)
                       .resizable()
                       .aspectRatio(contentMode: .fit)
                       .frame(width: 160 , height: 160)
                       .accessibilityLabel(image)

                       .padding(.bottom,80)
                   
                   Text(title ).accessibility(label: Text(title)) .multilineTextAlignment(.center)
                       .font(.title).foregroundColor(ColorPalette.buttonColor) .accessibilityLabel(title)
                       .padding()
                   
                   Text(Subtitle ) .accessibilityLabel(Subtitle)
                       .font(.caption)
                       .multilineTextAlignment(.center)
                       .foregroundColor(ColorPalette.buttonColor).accessibilityLabel(Subtitle)
                       .padding()
                       .padding(.bottom,120)
                   if DismissBoutton{
                       
                       Button(action: {
                           showOnboarding.toggle()
                       }, label:{
                           Text("Let's get creative together!")
                               .font(.system(size: 17))
                               .accessibilityLabel("Let's get creative together!")
                               .foregroundColor(Color.white)
                               .frame(width: 290,height: 60)
                               .background(ColorPalette.buttonColor)
                               .cornerRadius(15)
                               
                           
                       })
                       
                   }
                   
               }
               Spacer()
               
           
               
               
               
         }
       }
           .frame(maxWidth: .infinity, maxHeight:.infinity).background(Color.gray).edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
       
           }
}

#Preview {
    ContentView()
}

