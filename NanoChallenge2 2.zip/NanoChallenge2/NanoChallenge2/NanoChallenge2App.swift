//
//  NanoChallenge2App.swift
//  NanoChallenge2
//
//  Created by Haya Fahad Alsabr on 06/06/1445 AH.
//

import SwiftUI

@main
struct NanoChallenge2App: App {
    var body: some Scene {
        WindowGroup {
            LogoPage()
            //imageView()
        }
    }
}
