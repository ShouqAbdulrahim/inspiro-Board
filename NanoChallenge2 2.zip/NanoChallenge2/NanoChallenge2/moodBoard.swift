//
//  moodBoard.swift
//  NanoChallenge2
//
//  Created by Haya Fahad Alsabr on 11/06/1445 AH.
//

import SwiftUI
import Photos
import UIKit
struct moodBoard: View {
    @State var showActionSheet:Bool = false
    @State var showImagePicker : Bool = false
    @State var image : UIImage?
    //do u want to show the photo libriry or take a photo
    @State var sourceType: UIImagePickerController.SourceType = .camera
    
    @State var color : Color = ColorPalette.shapeColor
    @AppStorage("_showOnboarding") var showOnboarding : Bool=true
    @State var showAlert : Bool = false
    var body: some View {
        
        NavigationView{
            VStack{
                Spacer().frame(height: 75)
                //alignment:.top,
                HStack( spacing:290 ){
//                    Button {
//                    } label: {
//                        // Image(systemName: "arrow.clockwise.square")
//                        Image(systemName: "arrow.clockwise")
//                            .resizable() // تجعل الصورة قابلة للتحجيم
//                            .aspectRatio(contentMode: .fit) // تضبط نسبة العرض إلى الارتفاع
//                            .frame(width: 24, height: 24)
//                            .bold()
//                            .foregroundColor(ColorPalette.buttonColor)
//                    }.padding(.bottom,20)
                    Button {
                        guard let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
                              let window = windowScene.windows.first else {
                            // Unable to get the window
                            return
                        }

                        let renderer = UIGraphicsImageRenderer(bounds: window.bounds)
                        let screenshot = renderer.image(actions: { context in
                            window.drawHierarchy(in: window.bounds, afterScreenUpdates: true)
                        })

                        UIImageWriteToSavedPhotosAlbum(screenshot, nil, nil, nil)
                        showAlert = true
                    } label:  {
                        Image(systemName: "square.and.arrow.up")
                            .resizable() // تجعل الصورة قابلة للتحجيم
                            .aspectRatio(contentMode: .fit) // تضبط نسبة العرض إلى الارتفاع
                            .frame(width: 28, height: 29)
                            .bold()
                            .foregroundColor(ColorPalette.buttonColor)
                    }.padding(.bottom,20)
                        .alert(isPresented: $showAlert, content: {
                        Alert(title: Text("Your mood board has been successfully saved!"))})
                        .padding(.leading,320)
                    
                }
                HStack{
                    colorPickerShape(index: 0, width: 80, height: 68, title: "Color", label: "Add color image", pading: 0)
                    // .padding(.top,99)
                    colorPickerShape(index: 0, width: 80, height: 68, title: "Color", label: "Add color image", pading: 0)
                    colorPickerShape(index: 0, width: 80, height: 68, title: "Color", label: "Add color image", pading: 0)
                    colorPickerShape(index: 0, width: 80, height: 68, title: "Color", label: "Add color image", pading: 0)
                    // .padding(.top,99)
                    
                }
                
                ZStack(alignment:.top){
                    VStack{
                        HStack{
                            OtherShapes(index: 0, width: 168, height: 169, title: "Image", label: "Add Image", pading: 0)
                            
                            OtherShapes(index: 1, width: 168, height: 169, title: "Image", label: "Add Image", pading: 0)
                            
                            
                        }
                        HStack(alignment:.top){
                            OtherShapes(index: 0, width: 168, height: 310, title: "Image", label: "Add Image", pading: 0)
                            //2 shapes with 0 index
                            InfoShapes(index: 0)
                            // OtherShapes(index: 1)//2 shapes with 1 index
                        }
                    }
                    CircleSh(index: 0)
                }
                VStack{
                    HStack{
                        OtherShapes(index: 0, width: 168, height: 56, title: "Font", label: "Add Image Font", pading: 0)
                            .padding(.bottom,150)
                        OtherShapes(index: 0, width: 168, height: 164, title: "Image", label: "Add Image", pading: 0)
                            .padding(.top,-95)
                        
                    }
                    HStack{
                        TextFeild()
                    }//.padding(.trailing,177)
                    .padding(.top,-150)
                }
            }.frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(ColorPalette.backgroundColor)
                .edgesIgnoringSafeArea(.all)
        }
        .fullScreenCover(isPresented: $showOnboarding, content:{
            Onboarding_View(showOnboarding:$showOnboarding)
            })
    }
    
    
}

#Preview {
    moodBoard()
}
struct colorPickerShape : View{
    let index: Int
    @State var showActionSheet:Bool = false
    @State var showImagePicker : Bool = false
    @State var image : UIImage? = nil
    @State var sourceType: UIImagePickerController.SourceType = .camera
    @State var width:CGFloat
    @State var height:CGFloat
    @State var title:String
    @State var label:String
    @State var pading:CGFloat
    @State var color : Color = ColorPalette.shapeColor
    @Environment(\.dismiss) var dismiss
    var body: some View {
        ZStack{
            Rectangle()
                .frame(width: self.width, height: self.height)
                .foregroundColor(self.color)
                //.foregroundColor(.green)
            ColorPicker("", selection: $color)
                .labelsHidden()
            
        }
        
         
        
            .overlay(
             
                Button {
                    self.showActionSheet = true
                    
                } label: {
                    if let img = image {
                        Image(uiImage: img).resizable()
                    }else{
                        VStack{
//                            Image(systemName: "plus")
//                                .resizable()
//                                .aspectRatio(contentMode: .fit)
//                                .frame(width: 20, height: 20)
//                                .bold()
//                                .foregroundColor(ColorPalette.buttonColor)
                            
//                            Text("\(title)")
//                                .foregroundColor(ColorPalette.textColor)
//                                .font(.title3)
//                                .bold()
                            
                            
                            
                        }
                        
                        .padding(.bottom,self.pading)
                        .padding(.trailing,self.pading)
                        
                    }
                    
                    
                }
                      //  .actionSheet(isPresented: $showActionSheet) {
//                    ActionSheet(
//                        title: Text("Select Photo"),
//                        message: Text("choose"),
//                        buttons: [
//                            .default(Text("Photo Library")){
//                                self.showImagePicker = true
//                                self.sourceType = .photoLibrary
//                            },.default(Text("Camera")){
//                                self.showImagePicker = true
//                                self.sourceType = .camera
//                            },.cancel()
//
//                        ])
//                }
//                    .sheet(isPresented: $showImagePicker) {
//                        //show the model here
//                        ImagePicker(image: self.$image, isShown: self.$showImagePicker, sourceType: self.sourceType )
//                    }
                    .accessibility(label: Text("\(label)"))
            )
    }
}




struct OtherShapes: View {
    let index: Int
    @State var showActionSheet:Bool = false
    @State var showImagePicker : Bool = false
    @State var image : UIImage? = nil
    @State var sourceType: UIImagePickerController.SourceType = .camera
    @State var width:CGFloat
    @State var height:CGFloat
    @State var title:String
    @State var label:String
    @State var pading:CGFloat
    var body: some View {
        Rectangle()
            .frame(width: self.width, height: self.height)
            .foregroundColor(ColorPalette.shapeColor)
            .overlay(
                
                Button {
                    self.showActionSheet = true
                    guard let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
                          let window = windowScene.windows.first else {
                        // Unable to get the window
                        return
                    }

                    let renderer = UIGraphicsImageRenderer(bounds: window.bounds)
                    let screenshot = renderer.image(actions: { context in
                        window.drawHierarchy(in: window.bounds, afterScreenUpdates: true)
                    })
                    UIImageWriteToSavedPhotosAlbum(screenshot, nil, nil, nil)
                } label: {
                    if let img = image {
                        Image(uiImage: img).resizable()
                    }else{
                        VStack{
                            Image(systemName: "plus")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 20, height: 20)
                                .bold()
                                .foregroundColor(ColorPalette.buttonColor)
                            
                            Text("\(title)")
                                .foregroundColor(ColorPalette.textColor)
                                .font(.title3)
                                .bold()
                        }
                        .padding(.bottom,self.pading)
                        .padding(.trailing,self.pading)
                    }
                    
                    
                }.actionSheet(isPresented: $showActionSheet) {
                    ActionSheet(
                        title: Text("Select Photo"),
                        message: Text("choose"),
                        buttons: [
                            .default(Text("Photo Library")){
                                self.showImagePicker = true
                                self.sourceType = .photoLibrary
                            },.default(Text("Camera")){
                                self.showImagePicker = true
                                self.sourceType = .camera
                            },.cancel()
                            
                        ])
                }
                    .sheet(isPresented: $showImagePicker) {
                        //show the model here
                        ImagePicker(image: self.$image, isShown: self.$showImagePicker, sourceType: self.sourceType )
                    }
                    .accessibility(label: Text("\(label)"))
            )
        
    }
}

struct InfoShapes:View {
    let index: Int
    @State var showActionSheet: Bool = false
    @State var showImagePicker: Bool = false
    @State var image: UIImage? = nil
    @State var sourceType: UIImagePickerController.SourceType = .camera
    @State private var isInfoVisible = false
    @State private var isInfoVisible2 = false
    
    var body: some View {
        Rectangle()
            .frame(width: 168, height: 283)
            .foregroundColor(ColorPalette.shapeColor)
            .overlay(
                Button(action: {
                    self.showActionSheet = true
                }) {
                    VStack {
                        if let img = image {
                            Image(uiImage: img)
                            .resizable()
                            .scaledToFill() // Instead of aspectRatio(.fill)
                            .frame(width: 168, height: 283)
                            .clipShape(Rectangle())
                            .overlay(Rectangle().stroke(Color.clear, lineWidth: 10))
                            .padding(.bottom,15)
                            .padding(.trailing,20)
                            
                            
                            } else {
                            VStack {
                                Image(systemName: "plus")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(width: 20, height: 20)
                                    .bold()
                                    .foregroundColor(ColorPalette.buttonColor)
                                
                                Text("Visual metaphors")
                                    .foregroundColor(ColorPalette.textColor)
                                    .font(.title3)
                                    .bold()
                                
                                Button(action: {
                                    // Toggle the visibility of the info content
                                    isInfoVisible2.toggle()
                                }) {
                                    Image(systemName: "info.circle")
                                        .bold()
                                        .padding()
                                        .frame(width: 24, height: 24)
                                        .cornerRadius(10)
                                        .foregroundColor(Color.blue)
                                }
                                .accessibility(label: Text("Info Button"))
                                .padding(.top, -15)
                                .popover(isPresented: $isInfoVisible2, arrowEdge: .top) {
                                    VStack {
                                        Text("Visual metaphors")
                                            .foregroundColor(ColorPalette.buttonColor)
                                            .font(.title)
                                            .accessibilityLabel("Visual metaphors")
                                        
                                        Text("visual metaphors refer to the use of images, symbols, or representations that go beyond their literal meaning to convey abstract concepts, ideas, or emotions. Visual metaphors use visual elements to create a symbolic or suggestive connection, allowing viewers to infer deeper meanings or associations.")
                                            .foregroundColor(ColorPalette.buttonColor)
                                            .padding()
                                            .accessibilityLabel("visual metaphors refer to the use of images, symbols, or representations that go beyond their literal meaning to convey abstract concepts, ideas, or emotions. Visual metaphors use visual elements to create a symbolic or suggestive connection, allowing viewers to infer deeper meanings or associations.")
                                        Spacer().frame(height: 50)
                                        Button(action: {
                                            // Close the popover
                                            isInfoVisible2.toggle()
                                        }) {
                                            Text("Close")
                                                .padding()
                                                .foregroundColor(ColorPalette.buttonColor)
                                                .background(ColorPalette.textColor)
                                                .cornerRadius(10)
                                        }
                                        .accessibility(label: Text("Close Button"))
                                    }
                                    .padding()
                                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                                    .background(ColorPalette.backgroundColor)
                                    .ignoresSafeArea(.all)
                                }
                                .padding()
                            }
                        }
                    }
                    .padding(.top, 15)
                    .padding(.leading, 20)
                }
                .accessibility(label: Text("Add Visual metaphors"))
            )
            .frame(width: 168, height: 283)
            .actionSheet(isPresented: $showActionSheet) {
                ActionSheet(
                    title: Text("Select Photo"),
                    message: Text("Choose"),
                    buttons: [
                        .default(Text("Photo Library")) {
                            self.sourceType = .photoLibrary
                            self.showImagePicker = true
                        },
                        .default(Text("Camera")) {
                            self.sourceType = .camera
                            self.showImagePicker = true
                        },
                        .cancel()
                    ]
                )
            }
            .sheet(isPresented: $showImagePicker) {
                // Show the image picker here
                ImagePicker(image: self.$image, isShown: self.$showImagePicker, sourceType: self.sourceType)
            }
    }
}


struct CircleSh:View {
    let index: Int
    @State var showActionSheet:Bool = false
    @State var showImagePicker : Bool = false
    @State var image : UIImage? = nil
    @State var sourceType: UIImagePickerController.SourceType = .camera
    @State private var isInfoVisible = false
    var body: some View {
        Circle().stroke(ColorPalette.backgroundColor, lineWidth: 15)
            .fill(ColorPalette.shapeColor)
            .frame(width: 177, height: 175)
            .foregroundColor(ColorPalette.shapeColor)
            .padding(.top,100)
            .overlay(
                
                Button {
                    self.showActionSheet = true
                    self.showActionSheet = true
                    guard let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
                          let window = windowScene.windows.first else {
                        // Unable to get the window
                        return
                    }

                    let renderer = UIGraphicsImageRenderer(bounds: window.bounds)
                    let screenshot = renderer.image(actions: { context in
                        window.drawHierarchy(in: window.bounds, afterScreenUpdates: true)
                    })
                    UIImageWriteToSavedPhotosAlbum(screenshot, nil, nil, nil)
                } label: {
                    // Image(systemName: "arrow.clockwise.square")
                    if let img = image {
                        Image(uiImage: img)
                            .resizable()
                            .scaledToFill() // Instead of aspectRatio(.fill)
                            .frame(width: 177, height: 175)
                            .clipShape(Circle())
                            .overlay(Circle().stroke(Color.clear, lineWidth: 10))
                            .padding(.top,100)
                    }else{
                        VStack{
                            Image(systemName: "plus")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 20, height: 20)
                                .bold()
                                .foregroundColor(ColorPalette.buttonColor)
                                .accessibilityLabel("add Texture image ")
                            
                            HStack(spacing:-10 ){
                                
                                Text("Texture")
                                    .foregroundColor(ColorPalette.textColor)
                                    .font(.title3)
                                    .bold()
                                
                                Button(action: {
                                    // Toggle the visibility of the info content
                                    isInfoVisible.toggle()
                                }) {
                                    Image(systemName: "info.circle")
                                        .bold()
                                        .padding()
                                        .frame(width: 24, height: 24)
                                        .cornerRadius(10)
                                        .foregroundColor(Color.blue)
                                }.accessibility(label: Text("Info Button"))
                                    .popover(isPresented: $isInfoVisible, arrowEdge: .top) {
                                        // Content to be displayed in the popover
                                        VStack {
                                            Text("texture")
                                                .foregroundColor(ColorPalette.buttonColor)
                                                .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                                                .accessibilityLabel("Texture")
                                            
                                            Text("refers to the visual or tactile quality of a surface or material. \n It's an element that conveys the feel or appearance of a particular substance. Texture in a moodboard is often represented through images, patterns, or swatches that showcase the physical characteristics of materials such as fabric, paper, wood, metal, etc.")
                                                .foregroundColor(ColorPalette.buttonColor)
                                                .padding()
                                                .accessibilityLabel("refers to the visual or tactile quality of a surface or material. \n It's an element that conveys the feel or appearance of a particular substance. Texture in a moodboard is often represented through images, patterns, or swatches that showcase the physical characteristics of materials such as fabric, paper, wood, metal, etc.")
                                            Spacer().frame(height: 50)
                                            Button(action: {
                                                // Close the popover
                                                isInfoVisible.toggle()
                                            }) {
                                                Text("Close")
                                                    .padding()
                                                    .foregroundColor(ColorPalette.buttonColor)
                                                    .background(ColorPalette.textColor)
                                                    .cornerRadius(10)
                                            }
                                            
                                            .accessibility(label: Text("Close Button"))
                                        }
                                        .padding()
                                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                                        .background(ColorPalette.backgroundColor)
                                        .ignoresSafeArea(.all)
                                    }
                                    .padding()
                                
                            }
                            .padding(.leading,35)
                            
                            
                            
                        }
                        .actionSheet(isPresented: $showActionSheet) {
                            ActionSheet(
                                title: Text("Select Photo"),
                                message: Text("choose"),
                                buttons: [
                                    .default(Text("Photo Library")){
                                        self.showImagePicker = true
                                        self.sourceType = .photoLibrary
                                    },.default(Text("Camera")){
                                        self.showImagePicker = true
                                        self.sourceType = .camera
                                    },.cancel()
                                    
                                ])
                        }
                        .sheet(isPresented: $showImagePicker) {
                            //show the model here
                            ImagePicker(image: self.$image, isShown: self.$showImagePicker, sourceType: self.sourceType )
                        }
                        .padding(.top,70)
                        
                        
                    }

                    
                }
            )
    }
}

struct TextFeild:View {
    @State var subjectName = ""
    var body: some View {
        Rectangle()
            .frame(width: 168, height: 73)
            .foregroundColor(ColorPalette.shapeColor)
            .padding(.trailing,177)
            .overlay(
                
                TextField("Type a words", text: $subjectName)
                    .border(ColorPalette.textColor, width: 1)
                    .frame(width: 140 )
                    .frame(maxHeight: 300)
                    .foregroundColor(.brawnn) // Customize text color as needed
                    .font(.title3)
                    .bold()
                    .padding(.trailing,178)
                    .accessibilityLabel("Type a words")
                
                
            )
    }
}


public extension PHPhotoLibrary {
   
   static func execute(controller: UIViewController,
                       onAccessHasBeenGranted: @escaping () -> Void,
                       onAccessHasBeenDenied: (() -> Void)? = nil) {
      
      let onDeniedOrRestricted = onAccessHasBeenDenied ?? {
         let alert = UIAlertController(
            title: "We were unable to load your album groups. Sorry!",
            message: "You can enable access in Privacy Settings",
            preferredStyle: .alert)
         alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
         alert.addAction(UIAlertAction(title: "Settings", style: .default, handler: { _ in
            if let settingsURL = URL(string: UIApplication.openSettingsURLString) {
               UIApplication.shared.open(settingsURL)
            }
         }))
         DispatchQueue.main.async {
            controller.present(alert, animated: true)
         }
      }

      let status = PHPhotoLibrary.authorizationStatus()
      switch status {
      case .notDetermined:
         onNotDetermined(onDeniedOrRestricted, onAccessHasBeenGranted)
      case .denied, .restricted:
         onDeniedOrRestricted()
      case .authorized:
         onAccessHasBeenGranted()
      @unknown default:
         fatalError("PHPhotoLibrary::execute - \"Unknown case\"")
      }
   }
   
}

private func onNotDetermined(_ onDeniedOrRestricted: @escaping (()->Void), _ onAuthorized: @escaping (()->Void)) {
   PHPhotoLibrary.requestAuthorization({ status in
      switch status {
      case .notDetermined:
         onNotDetermined(onDeniedOrRestricted, onAuthorized)
      case .denied, .restricted:
         onDeniedOrRestricted()
      case .authorized:
         onAuthorized()
      @unknown default:
         fatalError("PHPhotoLibrary::execute - \"Unknown case\"")
      }
   })
}
