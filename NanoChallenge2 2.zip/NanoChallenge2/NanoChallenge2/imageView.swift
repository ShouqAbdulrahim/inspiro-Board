//
//  imageView.swift
//  NanoChallenge2
//
//  Created by Haya Fahad Alsabr on 07/06/1445 AH.
//

import SwiftUI

struct imageView: View {
    @State var showActionSheet:Bool = false
    @State var showImagePicker : Bool = false
    //do u want to show the photo libriry or take a photo
    @State var sourceType: UIImagePickerController.SourceType = .camera
    @State var image : UIImage?
    
    
    
    var body: some View {
        //wether use the image in line 15 or the defulte value
        Image(uiImage: image ?? UIImage(named: "Group 23")!)
            .resizable()
            .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, height: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/)
        Text("cc")
        
        Button("click"){
            //action sheet to allow user choose ohoto or take a phpto
            self.showActionSheet = true
            
        }
        .actionSheet(isPresented: $showActionSheet) {
            ActionSheet(
                title: Text("Select Photo"),
                message: Text("choose"),
                buttons: [
                    .default(Text("Photo Library")){
                        self.showImagePicker = true
                        self.sourceType = .photoLibrary
                    },.default(Text("Camera")){
                        self.showImagePicker = true
                        self.sourceType = .camera
                    },.cancel()
                
                ])
        }
        .sheet(isPresented: $showImagePicker) {
            //show the model here
            ImagePicker(image: self.$image, isShown: self.$showImagePicker, sourceType: self.sourceType )
        }
        // Q how can we display anything related to the photo library and the camera
        //A we have to use something called ( UI View Controller Representable )
        //it will aloow us to use image picker controller wich is part of UICit
        //to be avalibe in swiftui
    }
        
}

#Preview {
    imageView()
}
