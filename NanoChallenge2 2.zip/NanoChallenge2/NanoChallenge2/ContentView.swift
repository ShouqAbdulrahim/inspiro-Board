//
//  ContentView.swift
//  NanoChallenge2
//
//  Created by Haya Fahad Alsabr on 06/06/1445 AH.
//


import Foundation
import SwiftUI

struct LogoPage: View {
    //@State private var value = false
    //tells us weather the splash screen is active or not
    //@EnvironmentObject var viewModel: ViewModel

    @State var isActive : Bool = false
    
    @State var size = 0.8
    @State var opacity = 0.5
    
    var body: some View {
        if isActive == true {
            moodBoard()
        }
        else{
            //NavigationView{
            ZStack{
                Color("brawnn") .ignoresSafeArea()
                
                VStack{
                 VStack{
                    Spacer()
                        Image("Group 24") .resizable().scaledToFit().frame(width: 300, height: 300)
                            .scaleEffect(size).opacity(opacity) .onAppear()
                            {
                                withAnimation(.easeIn(duration: 1.2))
                                {
                                    self.size = 0.9
                                    self.opacity = 1.0
                                }
                                
                            }
                
//                        Image("LogoLungs")
//                            .resizable().scaledToFit() .frame(width: 200, height: 200)
//                            .imageScale(.large).scaleEffect(size).opacity(opacity)
//                            .onAppear(){
//                                withAnimation(.easeIn(duration: 1.2)){
//                                    self.size = 0.9
//                                    self.opacity = 1.0
//                                }
//                                
//                            }
                        
                            .padding(.bottom, -70.0)
                        Text("inspairo board ".uppercased())
                            .foregroundColor(.bej)
                            .frame(height: 100)
                            .bold()
                            .font(.system(size: 20))
                        
                            .scaleEffect(size)
                            .opacity(opacity)
                            .onAppear(){
                                withAnimation(.easeIn(duration: 1.2)){
                                    self.size = 0.9
                                    self.opacity = 1.0
                                }
                                
                            }
                        
                        
                        //NavigationLink("",destination:SecondContentView(),isActive: $value)
                        
                        
                        Spacer()
                        
                        //Button(action: {value = true}) {
                        // Text("Get started")
                        //  .padding(.horizontal,80)
                        //   .frame(height: 20)
                        //  .foregroundColor(.white)
                        //   .cornerRadius(8)
                        // }
                        // .buttonStyle(.borderedProminent)
                        //.tint(.darkBlue)
                        // .controlSize(.large)
                        
                        
                    }
                }
                
            }
            .onAppear(){
                DispatchQueue.main.asyncAfter(deadline:.now() + 2.0){
                    self.isActive = true
                    //viewModel.isOnboarding = false
                }
            }
                    }
                    }    }
            //}
#Preview {
    LogoPage()
}

