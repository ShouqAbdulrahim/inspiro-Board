//
//  colorPalette.swift
//  NanoChallenge2
//
//  Created by Haya Fahad Alsabr on 12/06/1445 AH.
//



import Foundation

import SwiftUI

struct ColorPalette {
    static let backgroundColor = Color(hex: "#DAD4C8")
    static let buttonColor = Color(hex: "#846046")
    static let shapeColor = Color(hex: "#E9E4DE")
    static let textColor = Color(hex: "#C4BDAF")
}

// Extension to create a Color from a hex string
extension Color {
    init(hex: String) {
        var hexSanitized = hex.trimmingCharacters(in: .whitespacesAndNewlines)
        hexSanitized = hexSanitized.replacingOccurrences(of: "#", with: "")

        var rgb: UInt64 = 0

        Scanner(string: hexSanitized).scanHexInt64(&rgb)

        self.init(
            red: Double((rgb & 0xFF0000) >> 16) / 255.0,
            green: Double((rgb & 0x00FF00) >> 8) / 255.0,
            blue: Double(rgb & 0x0000FF) / 255.0
        )
    }
}
